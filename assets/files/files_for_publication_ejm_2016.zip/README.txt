README file (v 1.1) August 2016

Authors: Fern�ndez Mac�as, Enrique, Hurley, John, and Bisello, Martina

GENERAL USAGE NOTES

This compressed folder contains all the necessary files to construct the set of indicators on the task content, methods and tools used at work, which are presented in the latest European Jobs Monitor (EJM) report "What do Europeans do at work? A task-based analysis: European Jobs Monitor 2016" (available at http://www.eurofound.europa.eu/publications/report/2016/labour-market/what-do-europeans-do-at-work-a-task-based-analysis-european-jobs-monitor-2016).

More specifically, the folder contains 6 different files of which 4 are Stata DO-files which allow to create the task indices directly from the original sources (i.e. EWCS, ONET and PIAAC) and to merge them with EU-LFS employment data in one unique database. The other two remaining files contain, in two different formats (Microsoft Excel Worksheet and Stata DTA), the task indices at the job level (defined as a combination of ISCO 08 and NACE Rev 2.0 at two-digit level). 

An additional document explaining in great detail the methodology of the construction of task indices for the European Jobs Monitor, including the selection of variables from original sources, is made available online and can be downloaded at the following link: http://www.eurofound.europa.eu/sites/default/files/ef1617en2.pdf





